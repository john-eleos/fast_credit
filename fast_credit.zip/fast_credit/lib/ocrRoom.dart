
import 'package:fast_credit/models/networkProvider.dart';
import 'package:flutter/material.dart';
class OcrRoom extends StatelessWidget {
  final NetworkProvider networkProvider;
  OcrRoom({Key key, @required this.networkProvider}):super (key:key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}