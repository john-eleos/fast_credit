import 'package:fast_credit/models/networkProvider.dart';
import 'package:flutter/material.dart';


List<NetworkProvider> networks = [
  NetworkProvider(0,"AIRTEL", "assets/images/", "*126*", Colors.redAccent),
  NetworkProvider(1,"9MOBILE", "assets/images/", "*222*", Colors.green[500]),
  NetworkProvider(2,"GLO", "assets/images/", "*123*", Colors.lightGreen),
  NetworkProvider(3,"MTN", "assets/images/", "*555*", Colors.yellowAccent),
];