
import 'package:flutter/material.dart';

class NetworkProvider{
  final int id;
  final String networkProviderName;
  final String networkProviderImage;
  final String networkProviderCode;
   Color color;

  NetworkProvider(this.id, this.networkProviderName, this.networkProviderImage, this.networkProviderCode, this.color, );
}

