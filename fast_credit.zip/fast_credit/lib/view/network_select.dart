import 'package:fast_credit/ocrRoom.dart';
import 'package:flutter/material.dart';
import 'package:fast_credit/provider/networkList.dart';

AnimationController animationController;
ColorTween colorTween;
CurvedAnimation curvedAnimation;
ScrollController scrollController;
class NetworkSelect extends StatefulWidget {
  NetworkSelect({Key key}) : super(key: key);

  @override
  _NetworkSelectState createState() => _NetworkSelectState();
}

class _NetworkSelectState extends State<NetworkSelect> with TickerProviderStateMixin{
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: networks.length,
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, index){
          return Padding(
            padding: EdgeInsets.only(left:25.0,
                right: 8.0,
                top: MediaQuery.of(context).size.height*0.25,
                bottom: MediaQuery.of(context).size.height*0.25),
            child: Container(
              height: MediaQuery.of(context).size.height*0.8,
              width: MediaQuery.of(context).size.width *0.8,
              child: Card(
                color: networks[index].color,
                child: FlatButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) => OcrRoom(networkProvider: networks[index],)
                  ));
                }, child: null),
              ),
            ),
          );
        },
    );
  }
}